/**
 * ============================================================================
 * PROJECTE: a2 — Matemàtiques per a l'aula d'acollida
 * FITXER: js/a-nombres-lletres/textos.js
 * ROL: Els textos de l'activitat «Escriure nombres» que veu l'alumne, tots junts.
 *      (Els del motor comú són a js/textos.js; el títol és a a-nombres-lletres.html
 *      i els noms dels nombres surten de generador.js.) Cada paraula ha de ser
 *      al lèxic (js/lexicon/dades.js): ho comprova tests/check-lexicon.js.
 *      L'única frase és la instrucció de cada pregunta; per a la resta, es llegeix amb el nombre en xifres i les opcions.
 * ============================================================================
 */

export const TEXTOS = {
    // Capçalera
    nombre: 'Nombre {n} de {total}',

    // Botons per canviar de nivell (el 1 no pot baixar i el 4 no pot pujar)
    baixaNivell: '‹ Baixar de nivell',
    pujaNivell: 'Pujar de nivell ›',

    // La instrucció de la pregunta (a sota de la capçalera)
    instruccio: 'Tria el nom del nombre.',
};
